import React, { useEffect } from "react"
import { getUsers } from "../redux/actions"
import { useDispatch, useSelector } from "react-redux"

const Home = () => {
    const dispatch = useDispatch()
    const user = useSelector(state => state.home.users)

    useEffect(() => {
        dispatch(getUsers())
    }, [dispatch])

    return (
        <div>
            <h1 onClick={() => console.log(localStorage.getItem('UserDetails'))}>HELLO</h1>
        </div>
    )
}

export default Home