import { combineReducers } from "redux";
import Home from "./Home";

const reducers = combineReducers({
    home: Home
})

export default reducers