import React, { useEffect } from "react"
import { connect } from "react-redux"
import { getUsers } from "../redux/actions"
import { useDispatch, useSelector } from "react-redux"

const Home = ({ userId }) => {

        const dispatch = useDispatch()
        const user = useSelector(state => state.user)

        useEffect(() => {
            dispatch(getUsers())
        },[dispatch, userId])


    return (
        <div>
            <h1 onClick={() => console.log(localStorage.getItem('UserDetails'))}>HELLO</h1>
        </div>
    )
}

const mapStateToProps = state => {
    return {
        getUsers
    }
}

export default connect(mapStateToProps, {getUsers})(Home)