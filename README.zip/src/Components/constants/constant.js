export const API_URL = "https://reqres.in/api"

export const REQUESTING = "REQUESTING"
export const SUCCESS = "SUCCESS"
export const ERROR = "ERROR"